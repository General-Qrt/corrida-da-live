# Corrida da Live — pacote para hospedagem (R$ 0)

Arquivos: `index.html` (jogo), `server.js` (servidor Node 20+), `package.json`, `.env.example`, `.gitignore`.

## O que funciona
- Jogo igual ao protótipo (mecânica inalterada) + painel **TikTok LIVE**.
- O servidor lê comentários `!correr`, presentes e novos seguidores de uma live **pública** pela biblioteca TikTok-Live-Connector. **Nenhuma credencial do TikTok é pedida** (não ative login/sessão).
- Eventos reais chegam marcados `[AO VIVO]`; botões de teste continuam `[SIM]`/`[TESTE]`. Corredores fictícios/simulados têm avatar com borda tracejada.
- Presente real: impulso vai para o corredor do **remetente** (se ele não está na corrida, nada acontece). Nível pelo total de diamantes: <10 = 1, 10–99 = 2, 100+ = 3 (ajustável por variável).

## Limites (leia antes)
- **Render grátis dorme após 15 min sem tráfego de entrada** (requisições HTTP ou mensagens de WebSocket vindas do navegador). Acordar leva ~1 min. Com o jogo aberto, ele envia um sinal a cada 25 s; se o iPhone bloquear a tela ou o Safari ficar em segundo plano, o sinal para e o servidor pode dormir.
- Há 750 horas grátis por mês (só contam enquanto o serviço está ativo). Se acabarem, o serviço é suspenso até o mês seguinte.
- A biblioteca é **não oficial** (engenharia reversa): o TikTok pode quebrá-la sem aviso. Também **não testei** a conexão com uma live real, e IPs de datacenter podem sofrer bloqueio ou limite (não verificado).
- Não há banco de dados: o histórico fica no próprio aparelho.

## Publicar usando só o iPhone

### 1. GitHub (Safari)
1. Entre em github.com e crie uma conta gratuita (confirme o e-mail).
2. Toque em **+ → New repository**. Nome: `corrida-da-live`. Marque **Public**. **Create repository**.
3. Baixe o `.zip` deste pacote, toque nele no app **Arquivos** para descompactar.
4. No repositório: **Add file → Upload files** → escolha, no Arquivos, `index.html`, `server.js` e `package.json` (os três juntos) → **Commit changes**.
   - Atenção: o app Arquivos do iPhone esconde arquivos que começam com ponto. `.env.example` e `.gitignore` são **opcionais**; para incluí-los, use **Add file → Create new file**, digite o nome e cole o conteúdo.
   - Não suba senhas nem PIN em nenhum arquivo.

### 2. Render (Safari)
1. Em render.com, **Get Started** → entre com GitHub e autorize o acesso ao repositório.
2. **New → Web Service** → escolha `corrida-da-live`.
3. Configure: Language **Node**; Branch **main**; Build Command `npm install`; Start Command `npm start`; Instance Type **Free**. Região: a mais próxima disponível (não verifiquei se há uma no Brasil).
4. Em **Environment Variables**, adicione:
   - `ADMIN_PIN` = um PIN que você inventar (obrigatório para conectar ao TikTok).
   - `NODE_VERSION` = `20` (só se o build reclamar da versão do Node).
   - Opcional: `TIKTOK_USERNAME` (seu @, sem o @) para conectar sozinho ao abrir o jogo.
5. **Deploy Web Service**. Quando aparecer **Live**, abra o endereço `https://….onrender.com` no Safari. Dica: **Compartilhar → Adicionar à Tela de Início**.
6. Confirme que o plano exibido é **Free** ($0) antes de finalizar. Se o Render pedir cartão, pare e me avise.

### 3. Testar
1. Abra o jogo: o selo deve mostrar **servidor online · sem live** (a primeira abertura pode levar ~1 min).
2. Sem live, tudo funciona em modo simulado.
3. Com uma live ativa: digite o @, o PIN e toque **Conectar**. O selo muda para **AO VIVO @…**.
4. Peça a um amigo para comentar `!correr` na live e confira `[AO VIVO]` no painel.

## Se algo falhar
- *Servidor offline*: aguarde 1 min (acordando) e recarregue.
- *Build falhou por versão do `tiktok-live-connector`*: veja o log do Render e me envie a mensagem.
- *Canal fora do ar*: o canal precisa estar ao vivo.
- Chave Euler Stream (`EULER_API_KEY`) é opcional, só para limites maiores, e fica apenas no servidor.
